

		<section class="breadcrumb_section text-white text-center text-uppercase d-flex align-items-end clearfix" data-background="img1.jpg">
            <div class="overlay" data-bg-color="#1d1d1d"></div>
            <div class="container">
                <h1 class="page_title text-white">Blog_Detail</h1>
                <ul class="breadcrumb_nav ul_li_center clearfix">
                    <li><a href="<?=base_url()?>index">Home</a></li>
                    <li>Blog_detail</li>
                </ul>
            </div>
        </section>
		
		<main>


			<!-- blog_section - start
			================================================== -->
			<section class="blog_section sec_ptb_140 clearfix">
				<div class="container">
					<div class="row justify-content-lg-between">
						<div class="col-lg-12 col-md-12">
							<div class="blog_grid">
								<div class="row">
									<div class="col-lg-6 ">
										<a class="blog_image1" >
											<img src="assets/images/Groceries_title.jpeg" alt="image_not_found">
										</a>
									</div>
									<div class="col-lg-6">
										<div class="blog_content p-0">
									<!-- <span class="blog_post_time text-uppercase bg_default_red text-white"><i class="fal fa-calendar-alt mr-1"></i> SEPTEMBER 21, 2020</span> -->
									<ul class="blog_category ul_li clearfix">
										
									</ul>
									<h3 class="blog_title">
										<a >Groceries</a>
									</h3>
									<p class="mb_31">
										Our place rule night were. Make, air great creepeth multiply herb evening saying beast very meat hath.Our place rule night were. Make, air great creepeth multiply herb evening saying beast very meat hath.</p>
									
								</div>
									</div>

								</div>
							</div>
						</div>

								
								


						<!--  -->


				</div>
			</section>
			<!-- blog_section - end
			================================================== -->


		</main>
		<!-- main body - end
		================================================== -->


	