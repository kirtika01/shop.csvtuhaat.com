
	
		<!-- js -->
		<script src="<?=base_url()?>assets/vendors/scripts/core.js"></script>
		<script src="<?=base_url()?>assets/vendors/scripts/script.min.js"></script>
		<script src="<?=base_url()?>assets/vendors/scripts/process.js"></script>
		<script src="<?=base_url()?>assets/vendors/scripts/layout-settings.js"></script>
		<script src="<?=base_url()?>assets/src/plugins/apexcharts/apexcharts.min.js"></script>
		<script src="<?=base_url()?>assets/src/plugins/datatables/js/jquery.dataTables.min.js"></script>
		<script src="<?=base_url()?>assets/src/plugins/datatables/js/dataTables.bootstrap4.min.js"></script>
		<script src="<?=base_url()?>assets/src/plugins/datatables/js/dataTables.responsive.min.js"></script>
		<script src="<?=base_url()?>assets/src/plugins/datatables/js/responsive.bootstrap4.min.js"></script>
		<script src="<?=base_url()?>assets/vendors/scripts/dashboard3.js"></script>

		<script src="<?=base_url()?>assets/src/plugins/jQuery-Knob-master/jquery.knob.min.js"></script>
		<script src="<?=base_url()?>assets/src/plugins/highcharts-6.0.7/code/highcharts.js"></script>
		<script src="<?=base_url()?>assets/src/plugins/highcharts-6.0.7/code/highcharts-more.js"></script>
		<script src="<?=base_url()?>assets/src/plugins/jvectormap/jquery-jvectormap-2.0.3.min.js"></script>
		<script src="<?=base_url()?>assets/src/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
		<script src="<?=base_url()?>assets/vendors/scripts/dashboard2.js"></script>


		<!-- buttons for Export datatable -->
	<script src="<?=base_url()?>assets/src/plugins/datatables/js/dataTables.buttons.min.js"></script>
	<script src="<?=base_url()?>assets/src/plugins/datatables/js/buttons.bootstrap4.min.js"></script>
	<script src="<?=base_url()?>assets/src/plugins/datatables/js/buttons.print.min.js"></script>
	<script src="<?=base_url()?>assets/src/plugins/datatables/js/buttons.html5.min.js"></script>
	<script src="<?=base_url()?>assets/src/plugins/datatables/js/buttons.flash.min.js"></script>
	<script src="<?=base_url()?>assets/src/plugins/datatables/js/pdfmake.min.js"></script>
	<script src="<?=base_url()?>assets/src/plugins/datatables/js/vfs_fonts.js"></script>

	<!-- Datatable Setting js -->
	<script src="<?=base_url()?>assets/vendors/scripts/datatable-setting.js"></script>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/js/bootstrap-select.min.js"></script>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>


	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.5.6/js/dataTables.buttons.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.flash.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.html5.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.print.min.js"></script>



	<!-- Google Tag Manager (noscript) -->
		<noscript
			><iframe
				src="https://www.googletagmanager.com/ns.html?id=GTM-NXZMQSS"
				height="0"
				width="0"
				style="display: none; visibility: hidden"
			></iframe
		></noscript>
		<!-- End Google Tag Manager (noscript) -->
	</body>
</html>
