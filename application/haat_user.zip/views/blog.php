
		<section class="breadcrumb_section text-white text-center text-uppercase d-flex align-items-end clearfix" data-background="<?= base_url()?>assets/images/img1.jpg">
            <div class="overlay" data-bg-color="#1d1d1d"></div>
            <div class="container">
                <h1 class="page_title text-white">Blog</h1>
                <ul class="breadcrumb_nav ul_li_center clearfix">
                    <li><a href="<?=base_url()?>index">Home</a></li>
                    <li>Blog</li>
                </ul>
            </div>
        </section>
	
		<main>
			<!-- blog_section - start
			================================================== -->
			<section class="blog_section sec_ptb_140 clearfix">
				<div class="container">
					<div class="row justify-content-lg-between">
						<div class="col-lg-6 col-md-6">
							<div class="blog_grid">
								<div class="row">
									<div class="col-lg-6 ">
										<a class="blog_image1" href="<?=base_url()?>blog_detail">
											<img src="assets/images/Groceries_title.jpeg" alt="image_not_found">
										</a>
									</div>
									<div class="col-lg-6">
										<div class="blog_content p-0">
									<!-- <span class="blog_post_time text-uppercase bg_default_red text-white"><i class="fal fa-calendar-alt mr-1"></i> SEPTEMBER 21, 2020</span> -->
									<ul class="blog_category ul_li clearfix">
										
									</ul>
									<h3 class="blog_title">
										<a href="<?=base_url()?>blog_detail">Groceries</a>
									</h3>
									<p class="mb_30">
										Our place rule night were. Make, air great creepeth multiply herb evening saying beast very meat hath.Our place rule night were. Make, air great creepeth multiply herb evening saying beast very meat hath.
									</p>
									<a class="custom_btn bg_default_black text-uppercase" href="<?=base_url()?>blog_detail">Read More <i class="fal fa-arrow-circle-right ml-2"></i></a>
								</div>
									</div>

								</div>
							</div>
						</div>

								
								


						<div class="col-lg-6 col-md-6">
							<div class="blog_grid">
								<div class="row">
									<div class="col-lg-6 ">
										<a class="blog_image1" href="<?=base_url()?>blog_detail">
											<img src="assets/images/Groceries_title.jpeg" alt="image_not_found">
										</a>
									</div>
									<div class="col-lg-6">
										<div class="blog_content p-0">
									<!-- <span class="blog_post_time text-uppercase bg_default_red text-white"><i class="fal fa-calendar-alt mr-1"></i> SEPTEMBER 21, 2020</span> -->
									<ul class="blog_category ul_li clearfix">
										
									</ul>
									<h3 class="blog_title">
										<a href="<?=base_url()?>blog_detail">Groceries</a>
									</h3>
									<p class="mb_30">
										Our place rule night were. Make, air great creepeth multiply herb evening saying beast very meat hath.Our place rule night were. Make, air great creepeth multiply herb evening saying beast very meat hath.
									</p>
									<a class="custom_btn bg_default_black text-uppercase" href="<?=base_url()?>blog_detail">Read More <i class="fal fa-arrow-circle-right ml-2"></i></a>
								</div>
									</div>

								</div>
							</div>
						</div>

						<div class="col-lg-6 col-md-6">
							<div class="blog_grid">
								<div class="row">
									<div class="col-lg-6 ">
										<a class="blog_image1" href="<?=base_url()?>blog_detail">
											<img src="assets/images/Groceries_title.jpeg" alt="image_not_found">
										</a>
									</div>
									<div class="col-lg-6">
										<div class="blog_content p-0">
									<!-- <span class="blog_post_time text-uppercase bg_default_red text-white"><i class="fal fa-calendar-alt mr-1"></i> SEPTEMBER 21, 2020</span> -->
									<ul class="blog_category ul_li clearfix">
										
									</ul>
									<h3 class="blog_title">
										<a href="<?=base_url()?>blog_detail">Groceries</a>
									</h3>
									<p class="mb_30">
										Our place rule night were. Make, air great creepeth multiply herb evening saying beast very meat hath.Our place rule night were. Make, air great creepeth multiply herb evening saying beast very meat hath.
									</p>
									<a class="custom_btn bg_default_black text-uppercase" href="<?=base_url()?>blog_detail">Read More <i class="fal fa-arrow-circle-right ml-2"></i></a>
								</div>
									</div>

								</div>
							</div>
						</div>


						<div class="col-lg-6 col-md-6">
							<div class="blog_grid">
								<div class="row">
									<div class="col-lg-6 ">
										<a class="blog_image1" href="<?=base_url()?>blog_detail">
											<img src="assets/images/Groceries_title.jpeg" alt="image_not_found">
										</a>
									</div>
									<div class="col-lg-6">
										<div class="blog_content p-0">
									<!-- <span class="blog_post_time text-uppercase bg_default_red text-white"><i class="fal fa-calendar-alt mr-1"></i> SEPTEMBER 21, 2020</span> -->
									<ul class="blog_category ul_li clearfix">
										
									</ul>
									<h3 class="blog_title">
										<a href="<?=base_url()?>blog_detail">Groceries</a>
									</h3>
									<p class="mb_30">
										Our place rule night were. Make, air great creepeth multiply herb evening saying beast very meat hath.Our place rule night were. Make, air great creepeth multiply herb evening saying beast very meat hath.
									</p>
									<a class="custom_btn bg_default_black text-uppercase" href="<?=base_url()?>blog_detail">Read More <i class="fal fa-arrow-circle-right ml-2"></i></a>
								</div>
									</div>

								</div>
							</div>
						</div>


						<div class="col-lg-6 col-md-6">
							<div class="blog_grid">
								<div class="row">
									<div class="col-lg-6 ">
										<a class="blog_image1" href="<?=base_url()?>blog_detail">
											<img src="assets/images/Groceries_title.jpeg" alt="image_not_found">
										</a>
									</div>
									<div class="col-lg-6">
										<div class="blog_content p-0">
									<!-- <span class="blog_post_time text-uppercase bg_default_red text-white"><i class="fal fa-calendar-alt mr-1"></i> SEPTEMBER 21, 2020</span> -->
									<ul class="blog_category ul_li clearfix">
										
									</ul>
									<h3 class="blog_title">
										<a href="<?=base_url()?>blog_detail">Groceries</a>
									</h3>
									<p class="mb_30">
										Our place rule night were. Make, air great creepeth multiply herb evening saying beast very meat hath.Our place rule night were. Make, air great creepeth multiply herb evening saying beast very meat hath.
									</p>
									<a class="custom_btn bg_default_black text-uppercase" href="<?=base_url()?>blog_detail">Read More <i class="fal fa-arrow-circle-right ml-2"></i></a>
								</div>
									</div>

								</div>
							</div>
						</div>


						<div class="col-lg-6 col-md-6">
							<div class="blog_grid">
								<div class="row">
									<div class="col-lg-6 ">
										<a class="blog_image1" href="<?=base_url()?>blog_detail">
											<img src="assets/images/Groceries_title.jpeg" alt="image_not_found">
										</a>
									</div>
									<div class="col-lg-6">
										<div class="blog_content p-0">
									<!-- <span class="blog_post_time text-uppercase bg_default_red text-white"><i class="fal fa-calendar-alt mr-1"></i> SEPTEMBER 21, 2020</span> -->
									<ul class="blog_category ul_li clearfix">
										
									</ul>
									<h3 class="blog_title">
										<a href="<?=base_url()?>blog_detail">Groceries</a>
									</h3>
									<p class="mb_30">
										Our place rule night were. Make, air great creepeth multiply herb evening saying beast very meat hath.Our place rule night were. Make, air great creepeth multiply herb evening saying beast very meat hath.
									</p>
									<a class="custom_btn bg_default_black text-uppercase" href="<?=base_url()?>blog_detail">Read More <i class="fal fa-arrow-circle-right ml-2"></i></a>
								</div>
									</div>

								</div>
							</div>
						</div>


					<!-- <ul class="pagination_nav ul_li_center text-uppercase clearfix">
						<li><a href="#!">Prev</a></li>
						<li class="active"><a href="#!">1</a></li>
						<li><a href="#!">2</a></li>
						
						<li><a href="#!">...</a></li>
						
						<li><a href="#!">Next</a></li>
					</ul> -->
				</div>
			</section>
			<!-- blog_section - end
			================================================== -->


		</main>
		<!-- main body - end
		================================================== -->


	